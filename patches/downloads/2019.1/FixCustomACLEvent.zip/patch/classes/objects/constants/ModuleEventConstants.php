<?php

class ModuleEventConstants
{

    const RUNS_ONCE = "once";

    const RUNS_MULTIPLE = "multiple";
}