<?php
class HomeViewModel {
	public $contentCount = 0;
	public $topPages = array ();
	public $lastModfiedPages = array ();
	public $admins = array ();
	public $guestbookEntryCount = null;
}