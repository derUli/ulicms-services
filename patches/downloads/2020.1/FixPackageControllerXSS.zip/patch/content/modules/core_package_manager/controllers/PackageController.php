<?php

declare(strict_types=1);

use UliCMS\Services\Connectors\PackageSourceConnector;
use function UliCMS\HTML\text;

class PackageController extends MainClass {

	const MODULE_NAME = "core_package_manager";

	public function afterSessionStart(): void {
		if (BackendHelper::getAction() == "modules") {
			Response::redirect(ModuleHelper::buildActionURL("packages"));
		}
	}

	public function getModuleInfo(): void {
		$name = stringOrNull(Request::getVar("name", null, "str"));
		if (!$name) {
			TextResult(get_translation("not_found"));
                        return;
		}
		$model = new ModuleInfoViewModel ();
		$model->name = $name;
		$model->version = getModuleMeta($name, "version");
		$model->manufacturerName = getModuleMeta($name, "manufacturer_name");
		$model->manufacturerUrl = getModuleMeta($name, "manufacturer_url");
		$model->source = getModuleMeta($name, "source");
		$model->source_url = $model->source === "extend" ?
				$this->getPackageDownloadUrl($model->name) : null;

		$model->customPermissions = is_array(
						getModuleMeta($name, "custom_acl")
				) ? getModuleMeta($name, "custom_acl") : [];
		$model->adminPermission = getModuleMeta($name, "admin_permission");
		natcasesort($model->customPermissions);
		ViewBag::set("model", $model);
		$html = Template::executeModuleTemplate(
						self::MODULE_NAME,
						"packages/info/module.php"
		);
		HTMLResult($html);
	}

	public function getPackageDownloadUrl(string $package): ?string {
		$url = "https://extend.ulicms.de/{$package}.html";
		return url_exists($url) ? $url : null;
	}

	public function getThemeInfo(): void {
		$name = stringOrNull(Request::getVar("name", null, "str"));
		if (!$name) {
			TextResult(get_translation("not_found"));
                        return;
		}
		$model = new ThemeInfoViewModel ();
		$model->name = $name;
		$model->version = getThemeMeta($name, "version");
		$model->manufacturerName = getThemeMeta($name, "manufacturer_name");
		$model->manufacturerUrl = getThemeMeta($name, "manufacturer_url");
		$model->source = getThemeMeta($name, "source");
		$model->source_url = $model->source === "extend" ?
				$this->getPackageDownloadUrl($model->name) : null;

		$model->disableFunctions = is_array(
						getThemeMeta($name, "disable_functions")
				) ? getThemeMeta($name, "disable_functions") : [];
		natcasesort($model->disableFunctions);
		ViewBag::set("model", $model);
		$html = Template::executeModuleTemplate(
						self::MODULE_NAME,
						"packages/info/theme.php"
		);
		HTMLResult($html);
	}

	public function redirectToPackageView(): void {
		Response::sendHttpStatusCodeResultIfAjax(
				HttpStatusCode::OK,
				ModuleHelper::buildActionURL("packages")
		);
	}

	public function uninstallModule(): void {
		$name = Request::getVar("name");
		$type = "module";
		if (uninstall_module($name, $type)) {
			$this->redirectToPackageView();
		} else {
			$errorMessage = get_secure_translation("removing_package_failed",
					[
						"%name%" => $name
					]
			);
			ExceptionResult($errorMessage, HttpStatusCode::INTERNAL_SERVER_ERROR);
		}
	}

	public function uninstallTheme(): void {
		$name = Request::getVar("name");
		$type = "theme";
		if (uninstall_module($name, $type)) {
			$this->redirectToPackageView();
		} else {
			$errorMessage = get_secure_translation("removing_package_failed", array(
				"%name%" => $name
			));
			ExceptionResult(
					$errorMessage,
					HttpStatusCode::INTERNAL_SERVER_ERROR
			);
		}
	}

	public function toggleModule(): void {
		$name = Request::getVar("name");

		$module = new Module($name);
		$oldState = $module->isEnabled();
		$newState = false;
		if ($oldState) {
			$module->disable();
			$newState = false;
		} else {
			$module->enable();
			$newState = true;
		}
		$module->save();
		JSONResult(array(
			"name" => $name,
			"enabled" => $newState
		));
	}

	public function truncatedInstalledPatches(): void {
		Database::truncateTable("installed_patches");
		TextResult("ok", HttpStatusCode::OK);
	}

	public function availablePackages(): void {
		$html = Template::executeModuleTemplate(
						self::MODULE_NAME,
						"packages/available_list.php"
		);
		HtmlResult($html);
	}

	public function getPackageLicense(): void {
		$name = Request::getVar("name");
		if (!$name) {
			HTTPStatusCodeResult(HttpStatusCode::UNPROCESSABLE_ENTITY);
		}
		$connector = new PackageSourceConnector();
		$license = $connector->getLicenseOfPackage($name);
		if (!$license) {
			HTTPStatusCodeResult(HttpStatusCode::NOT_FOUND);
		}
		HTMLResult(text($license));
	}

}
